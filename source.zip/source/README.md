# Serverless telegram bot
Hosting telegram bot with Yandex.Cloud Functions